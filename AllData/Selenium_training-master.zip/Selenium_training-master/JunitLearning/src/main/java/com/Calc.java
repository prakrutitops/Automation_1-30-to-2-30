package com;

public class Calc {
	
	public int add(int a, int b)
	{
		return a+b;
	}
}
